#ifndef _XT_REALM_H
#define _XT_REALM_H

struct xt_realm_info {
	u_int32_t id;
	u_int32_t mask;
	u_int8_t invert;
};

#endif /* _XT_REALM_H */
