#ifndef _IP6T_MARK_H
#define _IP6T_MARK_H

/* Backwards compatibility for old userspace */
#include <linux/netfilter/xt_mark.h>

#define ip6t_mark_info xt_mark_info

#endif /*_IPT_MARK_H*/
