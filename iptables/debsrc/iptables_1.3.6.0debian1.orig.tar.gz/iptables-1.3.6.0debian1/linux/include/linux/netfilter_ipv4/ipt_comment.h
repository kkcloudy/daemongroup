#ifndef _IPT_COMMENT_H
#define _IPT_COMMENT_H

#include <linux/netfilter/xt_comment.h>

#define IPT_MAX_COMMENT_LEN XT_MAX_COMMENT_LEN

#define ipt_comment_info xt_comment_info

#endif /* _IPT_COMMENT_H */
