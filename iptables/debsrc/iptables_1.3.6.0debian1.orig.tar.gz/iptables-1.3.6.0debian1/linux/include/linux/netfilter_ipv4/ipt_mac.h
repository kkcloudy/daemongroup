#ifndef _IPT_MAC_H
#define _IPT_MAC_H

#include <linux/netfilter/xt_mac.h>
#define ipt_mac_info xt_mac_info

#endif /*_IPT_MAC_H*/
