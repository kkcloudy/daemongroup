#ifndef _IP_CONNTRACK_FTP_H
#define _IP_CONNTRACK_FTP_H

#include <linux/netfilter/nf_conntrack_ftp.h>

#endif /* _IP_CONNTRACK_FTP_H */
